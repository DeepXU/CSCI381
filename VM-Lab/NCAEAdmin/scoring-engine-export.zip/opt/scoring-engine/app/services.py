SERVICES = [

    "router_icmp",

    "www_port_80",

    "www_content",

    "www_ssl",

    "ssh_login",

    "smb_login",

    "smb_write",

    "smb_read",

    "postgres_access",

    "dns_int_fwd",

    "dns_int_rev",

    "dns_ext_fwd",

    "dns_ext_rev",

]


